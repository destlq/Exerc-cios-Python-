horas = int(input("Informe as horas: "))
formula = horas * 60
print(horas, "horas em minutos são:", formula,"minutos") 