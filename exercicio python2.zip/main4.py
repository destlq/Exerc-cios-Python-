import math
angulo = float(input("Informe o ângulo em graus: "))
sct = math.radians(angulo)
print("Seno: ", math.sin(sct), "Cosseno: ", math.cos(sct), "Tangente: ", math.tan(sct))