h = float(input("Informe a altura do tronco da pirâmide: "))
bMenor = float(input("Informe a área da base menor da pirâmide: "))
bMaior = float(input("Informe a área da base maior da pirâmide: "))

formula = h / 3 * (bMaior**2 + bMenor**2 + (bMaior**2 * bMenor**2) ** 0.5)

print(f"O valor do tronco da pirâmide é: {formula:.2f} metros")