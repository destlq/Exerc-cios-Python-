import math
#Exemplo 3
custo = float(input("Informe o custo do espetáculo teatral: "))
ingresso = float(input("Informe o preço do ingresso: "))
minimo = int(custo / ingresso)
print("A quantidade mínima de convites a serem vendidos é de: ", minimo)
lucro = (minimo * 1.23 / ingresso)
print(" A quantidade de ingressos a serem vendidos para se ter um lucro de 23% é de : ", math.ceil(lucro))
