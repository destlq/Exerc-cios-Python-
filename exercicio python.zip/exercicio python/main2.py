import math
#Exemplo 2
a = int(input("Digite a medida do lado A: "))
b = int(input("Digite a medida do lado B: "))
hipotenusa = math.sqrt(a**2 + b**2)
print(f"O valor da hipotenusa do triângulo é {hipotenusa:.2f}")