#Exemplo 1 
evento = int(input("Informe os segundos de duração do evento: "))
horas = evento // 3600
minutos = (evento % 3600) // 60
segundos = evento % 60
print(f"O horário em {horas} horas, {minutos} minutos e {segundos} segundos")

